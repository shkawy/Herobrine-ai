package com.kriti;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntitySpawnReason;

public class Kriti implements ModInitializer {
    public static final String MOD_ID = "kriti";

    @Override
    public void onInitialize() {
        KritiConfig.load();
        ModEntities.init();
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            register(dispatcher, "kriti");
            register(dispatcher, "k");
        });
    }

    private static void register(CommandDispatcher<CommandSourceStack> dispatcher, String name) {
        dispatcher.register(Commands.literal(name)
                .then(Commands.literal("spawn").executes(ctx -> {
                    ServerPlayer player = ctx.getSource().getPlayerOrException();
                    ServerLevel level = ctx.getSource().getLevel();
                    HerobrineEntity e = ModEntities.HEROBRINE.create(level, EntitySpawnReason.COMMAND);
                    if (e == null) return 0;
                    e.setPos(player.getX(), player.getY(), player.getZ());
                    e.owner = player.getUUID();
                    level.addFreshEntity(e);
                    player.sendSystemMessage(Component.literal("\u00a7b<Kriti>\u00a7r Herobrine is here."));
                    return 1;
                }))
                .then(Commands.argument("message", StringArgumentType.greedyString())
                        .executes(ctx -> {
                            ServerPlayer player = ctx.getSource().getPlayerOrException();
                            String msg = StringArgumentType.getString(ctx, "message");
                            KritiChat.talk(ctx.getSource().getServer(), player, msg);
                            return 1;
                        })));
    }
}
