Kriti + Herobrine companion (Fabric 1.21.11)
/kriti spawn            -> summon the Herobrine-looking companion
/kriti <message>        -> chat; ask him to follow / stay / come / attack monsters
Without API key: keyword replies (تعال، وقف، هاجم، اتبعني). With key in config/kriti.json: smart chat that decides the action.
Build: new GitHub repo, upload kriti.zip, add .github/workflows/build.yml.
